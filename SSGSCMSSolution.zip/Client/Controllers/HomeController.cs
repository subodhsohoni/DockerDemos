﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Client.Models;
using System.Net;
using System.IO;
using System.Text.Json;
using System.Net.Http;
using System.Net.Http.Headers;

namespace Client.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public async Task<IActionResult> Index()
        {
            List<WeatherForecast> data = new List<WeatherForecast>();

            // http://localhost:5000/weatherforecast

            //HttpWebRequest httpRequest = (HttpWebRequest)WebRequest.Create("http://localhost:5000/weatherforecast");
            //httpRequest.ContentType = "application/json";
            //httpRequest.Method = "GET";
            HttpClient client = new HttpClient();
           // client.GetAsync("http://localhost:5000/weatherforecast");



            // using (HttpWebResponse httpResponse = (HttpWebResponse)httpRequest.GetResponse())
            using (var resposeMessage = await client.GetAsync("http://localhost:5000/weatherforecast"))
            {
                //using (Stream stream = resposeMessage.RequestMessage())
                //{
                //    string json = (new StreamReader(stream)).ReadToEnd();
                //    data = JsonSerializer.Deserialize<List<WeatherForecast>>(json);
                //}

                if (resposeMessage.IsSuccessStatusCode)
                {

                    Stream stream = await resposeMessage.Content.
                        ReadAsStreamAsync();
                        string json = (new StreamReader(stream)).ReadToEnd();
                        data = JsonSerializer.Deserialize<List<WeatherForecast>>(json);


                   
                }
            }


            return View(data);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
